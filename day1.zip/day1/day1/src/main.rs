fn sum(a: i32) -> i32{
    (0..a).sum()
}

fn main() {
    sum(10);
    println!("Hello world");
}
